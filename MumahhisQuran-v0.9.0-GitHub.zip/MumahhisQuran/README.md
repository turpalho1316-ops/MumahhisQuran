# مُمَحِّص القرآن — Mumahhis Quran

Android app for free Hifz revision by voice. The project is deliberately dependency-light: native Android Java, no Compose, no Firebase, no API key, and no Replit.

## What this build already does

- Arabic RTL interface.
- 114 surahs and standard ayah ranges.
- Downloads the Hafs Quran text once from Quran.ws and caches it on the device.
- Lets the user choose surah + start/end ayah.
- Hides the target text while testing.
- Uses the phone's Arabic speech recognizer (`ar-SA`).
- Keeps listening through short pauses and accumulates recognized segments.
- Normalizes Arabic for matching (harakat, Quranic marks, common alif/ya/hamza variants).
- Word-level dynamic-programming alignment.
- Detects: correct words, near matches, substitutions, missing words, extra words.
- Shows a percentage score and color-coded alignment.
- Can reveal the correct target text after the attempt.
- Works offline after the Quran text has been cached; speech recognition itself depends on the phone's installed speech service unless that service supports offline Arabic.

## Important limitation

This is a **word-sequence Hifz checker**, not a tajwid or makhraj judge. It does not claim Tarteel-level accuracy. The speech-to-text quality is controlled by the Android speech recognizer available on the user's device. The comparison engine is local and deterministic.

## Quran text source

The app does **not** bundle or alter a copy of the Quran text. At first launch it downloads the Hafs text directly from:

https://text.quran.ws/download?edition=hafs&format=txt

The source identifies the text as the King Fahd Glorious Quran Printing Complex (KFGQPC) Hafs/Uthmanic release and states that redistribution is subject to KFGQPC terms. See the in-app Sources section before redistributing the APK.

## Build on GitHub

This repository intentionally contains `.github/workflows/build-apk.yml`. GitHub Actions installs Gradle, builds `assembleDebug`, and uploads the resulting APK as a workflow artifact.

1. Extract this ZIP.
2. Create a GitHub repository and upload the **contents** of the extracted folder (not the ZIP file itself).
3. Make sure the default branch is `main`.
4. Open the repository's **Actions** tab. The workflow `Build Android APK` will run automatically after a push. It can also be started manually with **Run workflow**.
5. Open the completed workflow run and download the artifact named `MumahhisQuran-debug-apk`.

The current GitHub Actions setup follows GitHub/Gradle's documented artifact and Gradle setup flow.

## Project structure

- `app/src/main/java/com/mumahhis/quran/MainActivity.java` — UI + Android speech recognition.
- `app/src/main/java/com/mumahhis/quran/QuranRepository.java` — Quran download/cache/parser.
- `app/src/main/java/com/mumahhis/quran/QuranMatcher.java` — Arabic normalization + word alignment.
- `.github/workflows/build-apk.yml` — automatic APK build.

## Next engineering stage

The natural next step is to replace/augment Android's general Arabic ASR with a Quran-aware acoustic/phonetic layer, then add ayah-boundary detection, repeated-word recovery, mutashabihat warnings, revision history, and stronger confidence handling. Those improvements require real-device evaluation rather than pretending that a code-only implementation is already perfect.
