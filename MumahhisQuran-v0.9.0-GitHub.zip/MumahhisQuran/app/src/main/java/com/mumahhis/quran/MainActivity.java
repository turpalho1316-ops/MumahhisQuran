package com.mumahhis.quran;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.speech.*;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.*;
import android.widget.*;

import java.util.*;

public class MainActivity extends Activity {
    private static final int MIC_REQ = 41;
    private QuranRepository repo;
    private SpeechRecognizer recognizer;
    private boolean listening = false;
    private boolean loaded = false;
    private final StringBuilder heard = new StringBuilder();

    private Spinner surahSpinner;
    private NumberPicker fromPicker, toPicker;
    private Button startButton, finishButton, revealButton;
    private TextView status, liveText, resultTitle, resultStats, resultDetails, correctText;
    private ProgressBar progress;

    private static final String[] SURAH = {
        "الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"
    };
    private static final int[] AYAH_COUNTS = {
        7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        repo = new QuranRepository(this);
        loadQuran();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ);
    }

    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private TextView tv(String text, float sp, int color){ TextView t=new TextView(this); t.setText(text); t.setTextSize(sp); t.setTextColor(color); t.setPadding(dp(4),dp(4),dp(4),dp(4)); return t; }

    private void buildUi(){
        int bg=Color.rgb(245,243,237), dark=Color.rgb(16,35,27), gold=Color.rgb(201,168,76), muted=Color.rgb(90,98,93);
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(28)); scroll.addView(root);

        TextView title=tv("مُمَحِّص القرآن",28,dark); title.setGravity(Gravity.CENTER); title.setTypeface(null,1); root.addView(title);
        TextView sub=tv("مراجعة الحفظ بالصوت — نسخة تجريبية قوية",14,muted); sub.setGravity(Gravity.CENTER); root.addView(sub);

        status=tv("جاري تجهيز نص القرآن…",14,muted); status.setGravity(Gravity.CENTER); root.addView(status,new LinearLayout.LayoutParams(-1,dp(44)));
        progress=new ProgressBar(this); progress.setIndeterminate(true); root.addView(progress,new LinearLayout.LayoutParams(-1,dp(6)));

        root.addView(section("اختر موضع المراجعة",dark));
        surahSpinner=new Spinner(this); ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,SURAH); surahSpinner.setAdapter(ad); root.addView(surahSpinner);

        LinearLayout nums=new LinearLayout(this); nums.setGravity(Gravity.CENTER); nums.setPadding(0,dp(8),0,dp(8));
        fromPicker=picker(1,7,1); toPicker=picker(1,7,1);
        nums.addView(labelled("من آية",fromPicker),new LinearLayout.LayoutParams(0,dp(90),1));
        nums.addView(labelled("إلى آية",toPicker),new LinearLayout.LayoutParams(0,dp(90),1)); root.addView(nums);
        surahSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){int n=AYAH_COUNTS[pos];fromPicker.setMaxValue(n);toPicker.setMaxValue(n); if(fromPicker.getValue()>n)fromPicker.setValue(1); if(toPicker.getValue()>n)toPicker.setValue(n);}});

        TextView hint=tv("Совет: начинай с 3–10 аятов. Говори естественно, как в намазе. Приложение сопоставит слова и покажет пропуски, добавления и замены.",13,muted); root.addView(hint);
        LinearLayout buttons=new LinearLayout(this); buttons.setPadding(0,dp(8),0,0);
        startButton=button("▶  Начать проверку",dark); finishButton=button("■  Завершить",Color.DKGRAY); finishButton.setEnabled(false); revealButton=button("Показать правильный текст",dark); revealButton.setVisibility(View.GONE);
        buttons.addView(startButton,new LinearLayout.LayoutParams(0,dp(54),1)); buttons.addView(finishButton,new LinearLayout.LayoutParams(0,dp(54),1)); root.addView(buttons);
        root.addView(revealButton,new LinearLayout.LayoutParams(-1,dp(50)));

        root.addView(section("Речь",dark));
        liveText=tv("Здесь появится распознанная речь…",17,Color.DKGRAY); liveText.setTextDirection(View.TEXT_DIRECTION_RTL); liveText.setGravity(Gravity.CENTER_VERTICAL); root.addView(liveText,boxParams(110));

        resultTitle=tv("Результат",22,dark); resultTitle.setTypeface(null,1); resultTitle.setVisibility(View.GONE); root.addView(resultTitle);
        resultStats=tv("",15,dark); resultStats.setVisibility(View.GONE); root.addView(resultStats);
        resultDetails=tv("",16,dark); resultDetails.setTextDirection(View.TEXT_DIRECTION_RTL); resultDetails.setVisibility(View.GONE); root.addView(resultDetails,boxParams(-2));
        correctText=tv("",20,dark); correctText.setTextDirection(View.TEXT_DIRECTION_RTL); correctText.setGravity(Gravity.CENTER); correctText.setVisibility(View.GONE); root.addView(correctText,boxParams(-2));

        root.addView(section("Источники",dark));
        TextView credits=tv("Текст Корана: Quran.ws / KFGQPC (حفص). Текст загружается напрямую при первом запуске и сохраняется на устройстве. Сопоставление речи выполняется локально после получения текста.\n\nЭто не проверка таджвида: версия анализирует прежде всего последовательность слов. Распознавание речи зависит от системного Arabic ASR на устройстве.",12,muted); credits.setTextDirection(View.TEXT_DIRECTION_RTL); root.addView(credits);

        setContentView(scroll);
        startButton.setOnClickListener(v->startCheck()); finishButton.setOnClickListener(v->finishCheck()); revealButton.setOnClickListener(v->correctText.setVisibility(correctText.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
    }

    private TextView section(String s,int c){TextView t=tv(s,18,c);t.setTypeface(null,1);t.setPadding(0,dp(18),0,dp(7));return t;}
    private NumberPicker picker(int min,int max,int val){NumberPicker p=new NumberPicker(this);p.setMinValue(min);p.setMaxValue(max);p.setValue(val);p.setWrapSelectorWheel(false);return p;}
    private LinearLayout labelled(String s,View v){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);TextView t=tv(s,13,Color.DKGRAY);t.setGravity(Gravity.CENTER);l.addView(t);l.addView(v,new LinearLayout.LayoutParams(-1,dp(70)));return l;}
    private Button button(String s,int c){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTextColor(Color.WHITE);b.setBackgroundColor(c);b.setAllCaps(false);return b;}
    private LinearLayout.LayoutParams boxParams(int h){return new LinearLayout.LayoutParams(-1,h>0?dp(h):LinearLayout.LayoutParams.WRAP_CONTENT);}

    private void loadQuran(){
        status.setText("Загрузка проверенного текста Корана…"); progress.setVisibility(View.VISIBLE); startButton.setEnabled(false);
        repo.load(new QuranRepository.Callback(){public void onSuccess(){runOnUiThread(()->{loaded=true;progress.setVisibility(View.GONE);startButton.setEnabled(true);status.setText("✓ 6236 аятов готовы. Можно начинать.");});} public void onError(String m){runOnUiThread(()->{progress.setVisibility(View.GONE);status.setText("Не удалось загрузить текст: "+m+"\nПроверь интернет и запусти снова.");});}});
    }

    private void startCheck(){
        if(!loaded)return;
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_REQ);return;}
        List<QuranRepository.Ayah> range=repo.range(surahSpinner.getSelectedItemPosition()+1,fromPicker.getValue(),Math.max(fromPicker.getValue(),toPicker.getValue()));
        if(range.isEmpty()){status.setText("Не найден выбранный диапазон.");return;}
        heard.setLength(0); liveText.setText("Слушаю…"); resultTitle.setVisibility(View.GONE);resultStats.setVisibility(View.GONE);resultDetails.setVisibility(View.GONE);correctText.setVisibility(View.GONE);revealButton.setVisibility(View.GONE);
        startButton.setEnabled(false);finishButton.setEnabled(true);listening=true;status.setText("● Идёт проверка. После окончания нажми «Завершить».");
        if(recognizer==null) setupRecognizer(); listenOnce();
    }

    private void setupRecognizer(){
        recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){}
            public void onBeginningOfSpeech(){}
            public void onRmsChanged(float r){}
            public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){}
            public void onError(int e){ if(listening){new Handler(Looper.getMainLooper()).postDelayed(()->{if(listening)listenOnce();},350);} }
            public void onResults(Bundle b){
                ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(r!=null&&!r.isEmpty()){String s=r.get(0).trim();if(!s.isEmpty()){if(heard.length()>0)heard.append(' ');heard.append(s);liveText.setText(heard.toString());} if(listening) new Handler(Looper.getMainLooper()).postDelayed(()->{if(listening)listenOnce();},250);}
            }
            public void onPartialResults(Bundle b){ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(r!=null&&!r.isEmpty())liveText.setText((heard.length()>0?heard+" ":"")+r.get(0));}
            public void onEvent(int t,Bundle p){}
        });
    }

    private void listenOnce(){
        if(!listening)return;
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-SA");i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"ar-SA");i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,1800);i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS,1500);i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS,1200);
        try{recognizer.startListening(i);}catch(Exception e){status.setText("Не удалось запустить распознавание речи.");}
    }

    private void finishCheck(){
        listening=false; if(recognizer!=null)recognizer.stopListening(); startButton.setEnabled(true);finishButton.setEnabled(false);
        String heardText=heard.toString().trim(); int surah=surahSpinner.getSelectedItemPosition()+1; int from=fromPicker.getValue();int to=Math.max(from,toPicker.getValue());
        StringBuilder expected=new StringBuilder();for(QuranRepository.Ayah a:repo.range(surah,from,to)){if(expected.length()>0)expected.append(' ');expected.append(a.text);}
        if(heardText.isEmpty()){status.setText("Речь не распознана. Попробуй ещё раз говорить ближе к микрофону.");return;}
        QuranMatcher.Result r=QuranMatcher.compare(expected.toString(),heardText);
        showResult(r,expected.toString());
    }

    private void showResult(QuranMatcher.Result r,String expected){
        status.setText(r.score>=95?"✓ Очень хороший результат":"Проверка завершена"); resultTitle.setVisibility(View.VISIBLE);resultStats.setVisibility(View.VISIBLE);resultDetails.setVisibility(View.VISIBLE);revealButton.setVisibility(View.VISIBLE);
        resultStats.setText(String.format(Locale.US,"Точность: %.1f%%\n✓ правильно: %d   ≈ близко: %d   ✕ замены: %d   ↓ пропуски: %d   ↑ лишние: %d",r.score,r.correct,r.near,r.wrong,r.missing,r.extra));
        SpannableStringBuilder sb=new SpannableStringBuilder();int idx=0;
        for(QuranMatcher.Item x:r.items){String s;int color;switch(x.type){case CORRECT:s=x.expected+" ";color=Color.rgb(35,110,70);break;case NEAR:s="["+x.expected+" ≈ "+x.heard+"] ";color=Color.rgb(170,115,20);break;case WRONG:s="["+x.expected+" → "+x.heard+"] ";color=Color.rgb(190,55,45);break;case MISSING:s="[— "+x.expected+"] ";color=Color.rgb(190,55,45);break;default:s="[+ "+x.heard+"] ";color=Color.rgb(50,100,170);break;}int st=sb.length();sb.append(s);sb.setSpan(new ForegroundColorSpan(color),st,sb.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
        resultDetails.setText(sb);
        correctText.setText(expected);correctText.setVisibility(View.GONE);
    }

    @Override protected void onDestroy(){super.onDestroy();if(recognizer!=null){recognizer.destroy();recognizer=null;}}
}
