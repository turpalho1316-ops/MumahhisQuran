package com.mumahhis.quran;

import android.content.Context;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Downloads the Hafs/KFGQPC ayah file once and keeps it locally for offline reuse. */
public final class QuranRepository {
    public static final String SOURCE_URL = "https://text.quran.ws/download?edition=hafs&format=txt";
    private static final String CACHE_FILE = "quran-hafs.txt";

    private final Context context;
    private final ArrayList<Ayah> ayahs = new ArrayList<>();

    public QuranRepository(Context context) { this.context = context.getApplicationContext(); }

    public interface Callback { void onSuccess(); void onError(String message); }

    public void load(Callback callback) {
        new Thread(() -> {
            try {
                File cache = new File(context.getFilesDir(), CACHE_FILE);
                if (!cache.exists() || cache.length() < 100000) download(cache);
                parse(cache);
                callback.onSuccess();
            } catch (Exception e) {
                callback.onError(e.getMessage() == null ? "Не удалось загрузить текст Корана." : e.getMessage());
            }
        }).start();
    }

    private void download(File target) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(SOURCE_URL).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestMethod("GET");
        c.setRequestProperty("User-Agent", "MumahhisQuran/0.9");
        if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
        File tmp = new File(target.getParentFile(), CACHE_FILE + ".tmp");
        try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        } finally { c.disconnect(); }
        if (!tmp.renameTo(target)) throw new IOException("Не удалось сохранить базу Корана.");
    }

    private void parse(File file) throws Exception {
        ayahs.clear();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.isEmpty() || line.charAt(0) == '#') continue;
                String[] p = line.split("\\|", 3);
                if (p.length == 3) {
                    try { ayahs.add(new Ayah(Integer.parseInt(p[0]), Integer.parseInt(p[1]), p[2].trim())); }
                    catch (NumberFormatException ignored) { }
                }
            }
        }
        if (ayahs.size() < 6000) throw new IOException("База Корана неполная: " + ayahs.size() + " аятов.");
    }

    public List<Ayah> getAyahs() { return Collections.unmodifiableList(ayahs); }

    public List<Ayah> range(int surah, int from, int to) {
        ArrayList<Ayah> result = new ArrayList<>();
        for (Ayah a : ayahs) if (a.surah == surah && a.number >= from && a.number <= to) result.add(a);
        return result;
    }

    public static final class Ayah {
        public final int surah, number; public final String text;
        public Ayah(int surah, int number, String text) { this.surah = surah; this.number = number; this.text = text; }
    }
}
