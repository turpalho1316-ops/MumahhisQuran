package com.mumahhis.quran;

import java.text.Normalizer;
import java.util.*;

/** Word-level alignment engine: additions, omissions and substitutions. */
public final class QuranMatcher {
    private QuranMatcher() {}

    public enum Type { CORRECT, NEAR, MISSING, EXTRA, WRONG }
    public static final class Item {
        public final Type type; public final String expected; public final String heard;
        public Item(Type type, String expected, String heard) { this.type = type; this.expected = expected; this.heard = heard; }
    }
    public static final class Result {
        public final List<Item> items; public final int correct, near, missing, extra, wrong;
        public final double score;
        Result(List<Item> items, int correct, int near, int missing, int extra, int wrong) {
            this.items = items; this.correct = correct; this.near = near; this.missing = missing; this.extra = extra; this.wrong = wrong;
            int denom = Math.max(1, correct + near + missing + wrong + extra);
            this.score = Math.max(0, Math.min(100, 100.0 * (correct + 0.55 * near) / denom));
        }
    }

    public static String normalize(String s) {
        if (s == null) return "";
        s = Normalizer.normalize(s, Normalizer.Form.NFD);
        s = s.replaceAll("[\\u0610-\\u061A\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]", "");
        s = s.replace('ٱ','ا').replace('أ','ا').replace('إ','ا').replace('آ','ا')
                .replace('ٲ','ا').replace('ٳ','ا').replace('ى','ي').replace('ؤ','و').replace('ئ','ي')
                .replace('ـ','');
        s = s.replaceAll("[^\\p{InArabic}\\s]", " ");
        return s.trim().replaceAll("\\s+", " ");
    }

    public static List<String> tokens(String text) {
        String n = normalize(text); return n.isEmpty() ? new ArrayList<>() : new ArrayList<>(Arrays.asList(n.split("\\s+")));
    }

    private static int charDistance(String a, String b) {
        int[] prev = new int[b.length()+1], cur = new int[b.length()+1];
        for (int j=0;j<=b.length();j++) prev[j]=j;
        for (int i=1;i<=a.length();i++) {
            cur[0]=i;
            for (int j=1;j<=b.length();j++) cur[j]=Math.min(Math.min(cur[j-1]+1, prev[j]+1), prev[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));
            int[] t=prev; prev=cur; cur=t;
        }
        return prev[b.length()];
    }

    private static boolean near(String a, String b) {
        if (a.equals(b)) return false;
        int d = charDistance(a,b);
        return d <= 1 || (Math.min(a.length(), b.length()) >= 4 && d <= 2 && d * 3 <= Math.max(a.length(), b.length()));
    }

    public static Result compare(String expectedText, String heardText) {
        List<String> a = tokens(expectedText), b = tokens(heardText);
        int n=a.size(), m=b.size();
        int[][] dp = new int[n+1][m+1];
        byte[][] op = new byte[n+1][m+1]; // 0 diag, 1 delete expected, 2 insert heard
        for(int i=1;i<=n;i++){dp[i][0]=i;op[i][0]=1;}
        for(int j=1;j<=m;j++){dp[0][j]=j;op[0][j]=2;}
        for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) {
            int sub = dp[i-1][j-1] + (a.get(i-1).equals(b.get(j-1)) ? 0 : (near(a.get(i-1),b.get(j-1)) ? 1 : 2));
            int del = dp[i-1][j] + 1, ins = dp[i][j-1] + 1;
            dp[i][j]=sub; op[i][j]=0;
            if(del < dp[i][j]){dp[i][j]=del;op[i][j]=1;}
            if(ins < dp[i][j]){dp[i][j]=ins;op[i][j]=2;}
        }
        LinkedList<Item> out=new LinkedList<>(); int c=0,near=0,miss=0,extra=0,wrong=0;
        int i=n,j=m;
        while(i>0||j>0){
            if(i>0&&j>0&&op[i][j]==0){
                String x=a.get(i-1), y=b.get(j-1);
                if(x.equals(y)){out.addFirst(new Item(Type.CORRECT,x,y));c++;}
                else if(near(x,y)){out.addFirst(new Item(Type.NEAR,x,y));near++;}
                else{out.addFirst(new Item(Type.WRONG,x,y));wrong++;}
                i--;j--;
            } else if(i>0&&(j==0||op[i][j]==1)){out.addFirst(new Item(Type.MISSING,a.get(i-1),""));miss++;i--;
            } else {out.addFirst(new Item(Type.EXTRA,"",b.get(j-1)));extra++;j--;}
        }
        return new Result(out,c,near,miss,extra,wrong);
    }
}
